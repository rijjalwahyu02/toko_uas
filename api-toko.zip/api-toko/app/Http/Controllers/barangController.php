<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\barang;

class barangController extends Controller
{
    public function index()
    {
        $barang = barang::all();
        return response()->json($barang);
    }

    public function show($id)
    {
        $barang = barang::find($id);
        return response()->json($barang);
    }

    public function store(Request $request)
    {
        $barang = barang::create($request->all());
        return response()->json("Data Berhasil Ditambahkan");
    }

    public function update(Request $request, $id)
    {
        $barang = barang::find($id);
        $barang->update($request->all());
        return response()->json("Data Berhasil Diupdate");
    }

    public function destroy($id)
    {
        $barang = barang::find($id);
        $barang->delete();
        return response()->json("Data Berhasil Dihapus");
    }
}
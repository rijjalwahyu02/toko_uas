<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\stok;

class stokController extends Controller
{
    public function index()
    {
        $stok = stok::all();
        return response()->json($stok);
    }

    public function show($id)
    {
        $stok = stok::find($id);
        return response()->json($stok);
    }

    public function store(Request $request)
    {
        $stok = stok::create($request->all());
        return response()->json("Data Berhasil Ditambahkan");
    }

    public function update(Request $request, $id)
    {
        $stok = stok::find($id);
        $stok->update($request->all());
        return response()->json("Data Berhasil Diupdate");
    }

    public function destroy($id)
    {
        $stok = stok::find($id);
        $stok->delete();
        return response()->json("Data Berhasil Dihapus");
    }
}
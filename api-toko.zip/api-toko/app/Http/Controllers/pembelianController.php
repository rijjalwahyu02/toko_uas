<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\pembelian;

class pembelianController extends Controller
{
    public function index()
    {
        $pembelian = pembelian::all();
        return response()->json($pembelian);
    }

    public function show($id)
    {
        $pembelian = pembelian::find($id);
        return response()->json($pembelian);
    }

    public function store(Request $request)
    {
        $pembelian = pembelian::create($request->all());
        return response()->json("Data Berhasil Ditambahkan");
    }

    public function update(Request $request, $id)
    {
        $pembelian = pembelian::find($id);
        $pembelian->update($request->all());
        return response()->json("Data Berhasil Diupdate");
    }

    public function destroy($id)
    {
        $pembelian = pembelian::find($id);
        $pembelian->delete();
        return response()->json("Data Berhasil Dihapus");
    }
}
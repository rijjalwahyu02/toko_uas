<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\pelanggan;

class pelangganController extends Controller
{
    public function index()
    {
        $pelanggan = pelanggan::all();
        return response()->json($pelanggan);
    }

    public function show($id)
    {
        $pelanggan = pelanggan::find($id);
        return response()->json($pelanggan);
    }

    public function store(Request $request)
    {
        $pelanggan = pelanggan::create($request->all());
        return response()->json("Data Berhasil Ditambahkan");
    }

    public function update(Request $request, $id)
    {
        $pelanggan = pelanggan::find($id);
        $pelanggan->update($request->all());
        return response()->json("Data Berhasil Diupdate");
    }

    public function destroy($id)
    {
        $pelanggan = pelanggan::find($id);
        $pelanggan->delete();
        return response()->json("Data Berhasil Dihapus");
    }
}
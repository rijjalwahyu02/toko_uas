<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\pesanan;

class pesananController extends Controller
{
    public function index()
    {
        $pesanan = pesanan::all();
        return response()->json($pesanan);
    }

    public function show($id)
    {
        $pesanan = pesanan::find($id);
        return response()->json($pesanan);
    }

    public function store(Request $request)
    {
        $pesanan = pesanan::create($request->all());
        return response()->json("Data Berhasil Ditambahkan");
    }

    public function update(Request $request, $id)
    {
        $pesanan = pesanan::find($id);
        $pesanan->update($request->all());
        return response()->json("Data Berhasil Diupdate");
    }

    public function destroy($id)
    {
        $pesanan = pesanan::find($id);
        $pesanan->delete();
        return response()->json("Data Berhasil Dihapus");
    }
}
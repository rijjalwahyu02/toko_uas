<?php

namespace App\Models;
use Illuminate\Database\Eloquent\Model;


class pembelian extends Model
{
    protected $primaryKey = 'kode_pembelian';
    protected $table = 'pembelian';
    protected $fillable = [
        'kode_pesanan', 'kode_barang', 'jumlah', 'harga_total'
    ];
    protected $hidden = [];
}
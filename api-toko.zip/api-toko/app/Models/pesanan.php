<?php

namespace App\Models;
use Illuminate\Database\Eloquent\Model;


class pesanan extends Model
{
    protected $primaryKey = 'kode_pesanan';
    protected $table = 'pesanan';
    protected $fillable = [
        'kode_pesanan', 'kode_pelanggan', 'tanggal_pesanan', 'total_harga'
    ];
    protected $hidden = [];
}
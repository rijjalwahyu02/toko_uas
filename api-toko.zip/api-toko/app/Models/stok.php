<?php

namespace App\Models;
use Illuminate\Database\Eloquent\Model;


class stok extends Model
{
    protected $primaryKey = 'kode_barang';
    protected $table = 'stok';
    protected $fillable = [
        'kode_barang', 'stok_barang'
    ];
    protected $hidden = [];
}
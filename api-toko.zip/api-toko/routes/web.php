<?php

/** @var \Laravel\Lumen\Routing\Router $router */

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It is a breeze. Simply tell Lumen the URIs it should respond to
| and give it the Closure to call when that URI is requested.
|
*/

$router->get('/', function () use ($router) {
    return $router->app->version();
});

//generate key
$router->get('/Key', function() {
    return \Illuminate\Support\Str::random(32);
});

//grup route
$router->group(['prefix' => 'api'], function() use ($router) {
    //barang
    $router->get('/barang', 'barangController@index');
    $router->get('/barang/{id}', 'barangController@show');
    $router->post('/barang', 'barangController@store');
    $router->put('/barang/{id}', 'barangController@update');
    $router->delete('/barang/{id}', 'barangController@destroy');
    //pelanggan
    $router->get('/pelanggan', 'pelangganController@index');
    $router->get('/pelanggan/{id}', 'pelangganController@show');
    $router->post('/pelanggan', 'pelangganController@store');
    $router->put('/pelanggan/{id}', 'pelangganController@update');
    $router->delete('/pelanggan/{id}', 'pelangganController@destroy');
    //pembelian
    $router->get('/pembelian', 'pembelianController@index');
    $router->get('/pembelian/{id}', 'pembelianController@show');
    $router->post('/pembelian', 'pembelianController@store');
    $router->put('/pembelian/{id}', 'pembelianController@update');
    $router->delete('/pembelian/{id}', 'pembelianController@destroy');
    //pesanan
    $router->get('/pesanan', 'pesananController@index');
    $router->get('/pesanan/{id}', 'pesananController@show');
    $router->post('/pesanan', 'pesananController@store');
    $router->put('/pesanan/{id}', 'pesananController@update');
    $router->delete('/pesanan/{id}', 'pesananController@destroy');
    //stok
    $router->get('/stok', 'stokController@index');
    $router->get('/stok/{id}', 'stokController@show');
    $router->post('/stok', 'stokController@store');
    $router->put('/stok/{id}', 'stokController@update');
    $router->delete('/stok/{id}', 'stokController@destroy');


});